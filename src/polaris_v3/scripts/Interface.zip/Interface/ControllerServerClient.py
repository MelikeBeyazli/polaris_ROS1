import socket
import threading
import rospy
import rosnode
import rosservice
import rostopic
import time

# Function to send messages to the specified server (Arayüz bilgisayarına gönderim yapıyor)
def send_message_to_interface(message, host='aaa.bbb.c.32', port=65432):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as ros_client_socket:
            ros_client_socket.connect((host, port))
            ros_client_socket.sendall(message.encode())
            print(f"Sent to interface: {message}")
    except Exception as e:
        print(f"Failed to send message to interface: {e}")

# Function to handle connections from the admin client (Araçtaki admin istemcisi ile bağlantı kuruyor)
def handle_admin_client_connection(ros_client_socket):
    try:
        while True:
            data = ros_client_socket.recv(1024)
            if not data:
                break
            print(f"Received from admin client: {data.decode()}")
    except Exception as e:
        print(f"Error handling admin client connection: {e}")
    finally:
        ros_client_socket.close()

# Function to start the admin server (Araçtaki admin sunucusu)
def start_admin_server(host='aaa.bbb.c.21', port=65433):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as admin_server_socket:
        admin_server_socket.bind((host, port))
        admin_server_socket.listen()
        print(f"Admin server listening on {host}:{port}")

        while True:
            admin_client_socket, addr = admin_server_socket.accept()
            print(f"Admin client connected from {addr}")
            client_handler = threading.Thread(target=handle_admin_client_connection, args=(admin_client_socket,))
            client_handler.start()

# Function to connect to the second server and send messages (İkinci sunucuya bağlanma)
def connect_to_second_server(host='aaa.bbb.c.32', port=65434):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as second_server_socket:
            second_server_socket.connect((host, port))
            print(f"Connected to second server at {host}:{port}")
            second_server_socket.sendall("Connected to second server.".encode())
            send_message_to_interface("Connected to second server.", host='aaa.bbb.c.32', port=65432)
    except Exception as e:
        print(f"Failed to connect to second server: {e}")
        send_message_to_interface(f"Failed to connect to second server: {e}", host='aaa.bbb.c.32', port=65432)

# Function to check ROS connection (ROS bağlantısını kontrol etme)
def check_ros_connection(required_nodes=[]):
    try:
        # ROS düğümünü başlatma
        rospy.init_node('ros_connection_checker', anonymous=True)

        # Başlangıç mesajı
        initial_message = "Admin server started, listening..."
        print(initial_message)
        send_message_to_interface(initial_message)

        # ROS Master bağlantısını kontrol etme
        if rospy.get_master().getPid() == 0:
            error_message = "Unable to connect to ROS master."
            print(error_message)
            send_message_to_interface(error_message)
            return False

        success_message = "Connected to ROS master."
        print(success_message)
        send_message_to_interface(success_message)

        # Belirtilen ROS düğümlerini kontrol etme
        nodes = rosnode.get_node_names()
        nodes_message = "Available ROS nodes: " + ", ".join(nodes)
        print(nodes_message)
        send_message_to_interface(nodes_message)
        time.sleep(1)  # 1 saniye gecikme

        # Eksik düğümleri kontrol etme
        missing_nodes = [node for node in required_nodes if node not in nodes]
        if missing_nodes:
            warning_message = "WARNING: Missing required ROS nodes: " + ", ".join(missing_nodes)
            warning_message_big = f"\n\n!!! {warning_message} !!!\n\n"
            print(warning_message_big)
            send_message_to_interface(warning_message_big)
        else:
            print("All required ROS nodes are present.")

        # ROS konularını kontrol etme
        topics = rostopic.get_topic_list()
        topics_message = "Available ROS topics:"
        for topic in topics:
            topics_message += f"\n  {topic[0]} ({topic[1]})"
        print(topics_message)
        send_message_to_interface(topics_message)
        time.sleep(1)  # 1 saniye gecikme

        # ROS servislerini kontrol etme
        services = rosservice.get_service_list()
        services_message = "Available ROS services: " + ", ".join(services)
        print(services_message)
        send_message_to_interface(services_message)
        time.sleep(1)  # 1 saniye gecikme

        return True

    except Exception as e:
        error_message = f"An error occurred: {e}"
        print(error_message)
        send_message_to_interface(error_message)
        return False

# Function to start the main ROS server (ROS sunucusunu başlatma)
def start_ros_server(host='aaa.bbb.c.21', port=12345):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as ros_server_socket:
        ros_server_socket.bind((host, port))
        ros_server_socket.listen()
        print(f"ROS server listening on {host}:{port}")

        while True:
            ros_client_socket, addr = ros_server_socket.accept()
            print(f"ROS client connected from {addr}")
            client_handler = threading.Thread(target=handle_admin_client_connection, args=(ros_client_socket,))
            client_handler.start()

if __name__ == "__main__":
    # Gerekli ROS düğümlerini tanımlama
    required_nodes = ['/node1', '/node2', '/node3']  # Gerçek düğüm adları ile değiştirin

    # Admin sunucusunu başlatma
    admin_server_thread = threading.Thread(target=start_admin_server)
    admin_server_thread.start()

    # ROS sunucusunu başlatma
    ros_server_thread = threading.Thread(target=start_ros_server)
    ros_server_thread.start()

    # ROS bağlantısını kontrol etme
    connected = check_ros_connection(required_nodes=required_nodes)
    if connected:
        final_message = "Successfully connected to the ROS Master."
        print(final_message)
        send_message_to_interface(final_message)

        # İkinci sunucuya bağlanma ve mesaj gönderme
        connect_to_second_server()
    else:
        final_message = "Failed to connect to the ROS Master."
        print(final_message)
        send_message_to_interface(final_message)
