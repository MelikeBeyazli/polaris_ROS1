# -*- coding: utf-8 -*-
# !/usr/bin/env python3
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QIcon
from polaris_ui import Ui_Polaris
import socket
import threading

import time


class PolarisApp(QtWidgets.QMainWindow, Ui_Polaris):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)

        # Initially show the intro panel
        self.stackedWidget.setCurrentWidget(self.intro_panel)

        # Timer for transitioning from intro_panel to start_panel
        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.showStartPanel)
        self.timer.start(5000)  # 5 seconds delay

        # Connect StartButton to function
        self.StartButton.clicked.connect(self.startButtonClicked)

        # Server variables
        self.host = '192.168.1.32'
        self.port = 12345
        self.server_socket = None
        self.client_socket = None
        self.client_address = None

        # Thread lock for updating UI from thread
        self.lock = threading.Lock()
        # Counter for loading bar value
        self.loading_counter = 0

    def updateLoadingBar(self, message):
        """Update the loading bar value and message in increments."""
        with self.lock:
            if self.loading_counter < 100:
                self.loading_counter += 1
                self.loading_no.setText(f"%{self.loading_counter}")
                self.loading_info.setText(message)
                QtCore.QCoreApplication.processEvents()

    def showStartPanel(self):
        """Transition from intro panel to start panel."""
        self.stackedWidget.setCurrentWidget(self.start_panel)

    def showControlPanel(self):
        """Transition from start panel to control panel."""
        self.stackedWidget.setCurrentWidget(self.control_panel)

    def startButtonClicked(self):
        """Start the server in a new thread."""
        threading.Thread(target=self.runServer, daemon=True).start()

    def runServer(self):
        """Run the server and handle connections."""
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        try:
            # Bind the socket to the specified IP and port
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(1)
            self.updateLoadingBar("Server started, listening...")

            while True:
                self.updateLoadingBar("Waiting for client connection...")
                self.client_socket, self.client_address = self.server_socket.accept()
                self.updateLoadingBar(f"Client connected: {self.client_address}")
                threading.Thread(target=self.handleClient, daemon=True).start()

                # Transition to control panel after a connection
                self.timer2 = QtCore.QTimer()
                self.timer2.timeout.connect(self.showControlPanel)
                self.timer2.start(5000)  # 5 seconds delay

        except socket.error as e:
            self.updateLoadingBar(f"Connection error: {e}")
        finally:
            if self.server_socket:
                self.server_socket.close()
            if self.client_socket:
                self.client_socket.close()

    def handleClient(self):
        """Handle communication with a connected client."""
        try:
            while True:
                data = self.client_socket.recv(1024)
                if not data:
                    break
                message = data.decode()
                self.updateLoadingBar(f"Received from client: {message}")
        except socket.error as e:
            self.updateLoadingBar(f"Client error: {e}")


if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    app.setWindowIcon(QIcon("logo4.png"))
    window = PolarisApp()
    window.show()
    sys.exit(app.exec_())
