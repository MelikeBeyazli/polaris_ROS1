import socket
import threading
import rospy
import rosnode
import rosservice
import rostopic
import time
server_host = "192.168.1.32"
server_port_ros = 12345
# Function to send messages to the specified server
def send_message_to_server(message, host,  port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as ros_client_socket:
            ros_client_socket.connect((host, port))
            ros_client_socket.sendall(message.encode())
            print(f"Sent to server: {message}")
    except Exception as e:
        print(f"Failed to send message to server: {e}")

# Function to check ROS connection
def check_ros_connection():
    try:
        # Initialize the ROS node with a unique name
        rospy.init_node('ros_connection_checker', anonymous=True)

        # Initial message indicating the admin server is starting
        initial_message = "Admin server started, listening..."
        print(initial_message)
        send_message_to_server(initial_message, host=server_host, port=server_port_ros)

        # Check if the ROS Master is available
        if rospy.get_master().getPid() == 0:
            error_message = "Unable to connect to ROS master."
            print(error_message)
            send_message_to_server(error_message, host=server_host, port=server_port_ros)
            return False

        success_message = "Connected to ROS master."
        print(success_message)
        send_message_to_server(success_message, host=server_host, port=server_port_ros)

        # Check if specific ROS nodes are available
        nodes = rosnode.get_node_names()
        nodes_message = "Available ROS nodes: " + ", ".join(nodes)
        print(nodes_message)
        send_message_to_server(nodes_message, host=server_host, port=server_port_ros)
        time.sleep(1)  # 1-second delay
        """
        # Check for required nodes and send warnings if any are missing
        missing_nodes = [node for node in required_nodes if node not in nodes]
        if missing_nodes:
            warning_message = "WARNING: Missing required ROS nodes: " + ", ".join(missing_nodes)
            warning_message_big = f"\n\n!!! {warning_message} !!!\n\n"
            print(warning_message_big)
            send_message_to_server(warning_message_big, host=server_host, port=server_port_ros)
        else:
            print("All required ROS nodes are present.")
        """
        # Check if specific topics are available
        topics = rostopic.get_topic_list()
        topics_message = "Available ROS topics:"
        for topic in topics:
            topics_message += f"\n  {topic[0]} ({topic[1]})"
        print(topics_message)
        send_message_to_server(topics_message, host=server_host, port=server_port_ros)
        time.sleep(1)  # 1-second delay

        # Check if specific services are available
        services = rosservice.get_service_list()
        services_message = "Available ROS services: " + ", ".join(services)
        print(services_message)
        send_message_to_server(services_message, host=server_host, port=server_port_ros)
        time.sleep(1)  # 1-second delay

        return True

    except Exception as e:
        error_message = f"An error occurred: {e}"
        print(error_message)
        send_message_to_server(error_message, host=server_host, port=server_port_ros)
        return False

if __name__ == "__main__":
    # Define the required ROS nodes
    # required_nodes = ["/serial_node"]  # Replace with actual node names

   # Check ROS connection and send messages accordingly
    connected = check_ros_connection()
    if connected:
        final_message = "Successfully connected to the ROS Master."
        print(final_message)
        send_message_to_server(final_message, host=server_host, port=server_port_ros)

    else:
        final_message = "Failed to connect to the ROS Master."
        print(final_message)
        send_message_to_server(final_message, host=server_host, port=server_port_ros)
