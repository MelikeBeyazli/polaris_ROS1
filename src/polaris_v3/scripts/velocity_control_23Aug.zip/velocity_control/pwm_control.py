import math, time

# import sensorData

# Araç parametreleri
L = 0.6  # Tekerlekler arası mesafe (m)
r = 0.085  # Tekerlek yarıçapı (m)
rpm = 230  # Devir/dk
i = 1 / 15  # Motor redüksiyon oranı

# Maksimum hızın hesaplanması
Vmax = (rpm / i) * ((2 * math.pi) / 60) * r

import math

def calculate_acceleration_profiles(_v0, _v1, _x0, _x1):
    if _v1!=_v0:
        # İki nokta arasındaki mesafenin hesaplanması
        delta_x = math.sqrt((_x1[0] - _x0[0]) ** 2 + (_x1[1] - _x0[1]) ** 2)  # metre cinsinden yerdeğiştirme miktarı
        _a = (_v1 ** 2 - _v0 ** 2) / (2 * delta_x)  # m/s^2 cinsinden ivme
        _t = abs(_v1 - _v0) / abs(_a)
        start_time = time.time()
        elapsed_time = time.time() - start_time
        _x = 0
        while elapsed_time <= _t:
            _v1 = _v0 + _a * elapsed_time
            _x = _v0 * elapsed_time + (_a * elapsed_time ** 2) / 2
            elapsed_time = time.time() - start_time
            print(f"v1:{_v1}  : t:{elapsed_time}  : x:{_x}")
    return _v1



def send_wheel_vel(v1_, teta_deg_):
    # Derece cinsinden verilen açıyı radian cinsine çevir
    _teta = math.radians(teta_deg_)
    # Açısal hız (omega) - Bu hesaplamada derece kullanmak yerine, radian cinsinden açıyı kullandık
    omega = _teta / 100  # rad/s olarak alınıyor

    # Tekerlek hızları
    v_l = (2 * v1_ - omega * L) / 2  # sol tekerlek hızı
    v_r = (2 * v1_ + omega * L) / 2  # sağ tekerlek hızı

    # Yönleri belirleyin
    r_dir = v_r >= 0.0
    l_dir = v_l >= 0.0

    r_pwm = int(constrain((abs(v_r) / Vmax) * 255, 0, 255))
    l_pwm = int(constrain((abs(v_l) / Vmax) * 255, 0, 255))

    pwm_values = [r_pwm, l_pwm]
    dir_values = [r_dir, l_dir]

    # sensorData.motor_control(pwm_values, dir_values)
    print(f"v_l: {v_l}, l_dir: {l_dir}")
    print(f"v_r: {v_r}, r_dir: {r_dir}")


def constrain(value, min_value, max_value):
    return max(min_value, min(value, max_value))
v0=0
v1= 0
teta= 180
v1 = calculate_acceleration_profiles(_v0=v0, _v1=v1, _x0=[4, 3], _x1=[8, 6])
send_wheel_vel(v1_=v1, teta_deg_=teta)
